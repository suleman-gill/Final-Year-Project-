"""
Tilawah AI — Audio Preprocessing Pipeline.

Converts base64-encoded PCM audio from the Flutter client into
16 kHz PyTorch tensors ready for Wav2Vec2 inference.
"""

import base64
import io
import struct
import logging
from typing import Optional, Tuple

import numpy as np
import soundfile as sf

logger = logging.getLogger("uvicorn")

# ── Constants ─────────────────────────────────────────────────────────
TARGET_SAMPLE_RATE = 16_000  # Wav2Vec2 requirement
PCM_DTYPE = np.int16         # 16-bit signed PCM from Flutter's AudioRecorder


def validate_audio_frame(base64_str: str, max_bytes: int) -> bool:
    """
    Check if the base64-encoded audio frame is within the allowed size.

    Args:
        base64_str: Raw base64 string from the WebSocket payload.
        max_bytes: Maximum allowed size in bytes (default 1 MB).

    Returns:
        True if the frame is within limits, False otherwise.
    """
    # Base64 encodes 3 bytes into 4 characters.
    # Estimated decoded size = len(base64_str) * 3 / 4
    estimated_bytes = len(base64_str) * 3 // 4
    return estimated_bytes <= max_bytes


def decode_audio_base64(
    base64_str: str,
    sample_rate: int = TARGET_SAMPLE_RATE,
    num_channels: int = 1,
) -> np.ndarray:
    """
    Decode a base64-encoded PCM16 or WAV audio chunk into a numpy float32 array.

    Supports both raw PCM16 bytes and full WAV files.
    """
    raw_bytes = base64.b64decode(base64_str)

    if len(raw_bytes) < 2:
        logger.warning("[AudioUtils] Received audio frame with < 2 bytes, returning empty array.")
        return np.array([], dtype=np.float32)

    # Check if the audio is a WAV file (starts with RIFF header)
    if raw_bytes.startswith(b'RIFF'):
        try:
            data, sr = sf.read(io.BytesIO(raw_bytes))
            if len(data.shape) > 1:
                # Convert multi-channel to mono
                data = np.mean(data, axis=-1)
            # Resample to 16kHz if the sample rate is different
            if sr != TARGET_SAMPLE_RATE:
                data = resample_to_16khz(data, sr)
            return data.astype(np.float32)
        except Exception as e:
            logger.error(f"[AudioUtils] Failed to decode WAV using soundfile: {e}")

    # Interpret raw bytes as signed 16-bit integers (little-endian)
    num_samples = len(raw_bytes) // 2
    pcm_samples = np.frombuffer(raw_bytes[:num_samples * 2], dtype=np.int16)

    # Normalize to float32 [-1.0, 1.0]
    audio_float = pcm_samples.astype(np.float32) / 32768.0

    return audio_float


def resample_to_16khz(
    audio_array: np.ndarray,
    original_sr: int,
) -> np.ndarray:
    """
    Resample audio to 16 kHz using torchaudio.

    If the audio is already at 16 kHz, this is a no-op.

    Args:
        audio_array: Numpy float32 audio array.
        original_sr: The original sample rate of the audio.

    Returns:
        Numpy float32 array resampled to 16 kHz.
    """
    if original_sr == TARGET_SAMPLE_RATE:
        return audio_array

    try:
        import torchaudio
        import torch

        tensor = torch.from_numpy(audio_array).unsqueeze(0)  # [1, num_samples]
        resampler = torchaudio.transforms.Resample(
            orig_freq=original_sr,
            new_freq=TARGET_SAMPLE_RATE,
        )
        resampled = resampler(tensor)
        return resampled.squeeze(0).numpy()
    except ImportError:
        logger.warning(
            "[AudioUtils] torchaudio not available for resampling. "
            "Returning original audio (sample rate mismatch may affect model accuracy)."
        )
        return audio_array


def audio_to_tensor(audio_array: np.ndarray):
    """
    Convert a numpy float32 audio array into a PyTorch tensor.

    Args:
        audio_array: Numpy float32 audio array normalized to [-1.0, 1.0].

    Returns:
        1-D PyTorch float32 tensor ready for Wav2Vec2 input.
    """
    import torch
    return torch.from_numpy(audio_array).float()


def compute_audio_energy(audio_array: np.ndarray) -> float:
    """
    Compute the Root Mean Square (RMS) energy of the audio signal.

    Used by the FallbackCalculatedEngine to determine whether the
    audio frame contains actual speech or is silence/noise.

    Args:
        audio_array: Numpy float32 audio array.

    Returns:
        RMS energy as a float. Silence typically < 0.01, speech > 0.02.
    """
    if len(audio_array) == 0:
        return 0.0
    return float(np.sqrt(np.mean(audio_array ** 2)))


def compute_audio_duration_ms(audio_array: np.ndarray, sample_rate: int = TARGET_SAMPLE_RATE) -> float:
    """
    Compute the duration of the audio in milliseconds.

    Args:
        audio_array: Numpy float32 audio array.
        sample_rate: The sample rate of the audio.

    Returns:
        Duration in milliseconds.
    """
    if len(audio_array) == 0:
        return 0.0
    return (len(audio_array) / sample_rate) * 1000.0


def is_speech_present(
    audio_array: np.ndarray,
    energy_threshold: float = 0.015,
    min_duration_ms: float = 100.0,
    sample_rate: int = TARGET_SAMPLE_RATE,
) -> bool:
    """
    Simple Voice Activity Detection (VAD) based on energy and duration.

    Determines whether the audio frame likely contains speech rather
    than silence or background noise.

    Args:
        audio_array: Numpy float32 audio array.
        energy_threshold: Minimum RMS energy to consider as speech.
        min_duration_ms: Minimum duration in ms to consider as a valid utterance.
        sample_rate: Sample rate of the audio.

    Returns:
        True if the audio likely contains speech.
    """
    energy = compute_audio_energy(audio_array)
    duration = compute_audio_duration_ms(audio_array, sample_rate)
    return energy >= energy_threshold and duration >= min_duration_ms
