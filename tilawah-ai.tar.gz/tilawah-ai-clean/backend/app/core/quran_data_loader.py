"""
Tilawah AI — Quran Ground-Truth Data Loader.

Loads Quran text from a local JSON file for offline operation.
Falls back to the alquran.cloud API when the local file is missing.
"""

import json
import os
import re
import logging
from typing import Dict, List, Optional
from pathlib import Path

logger = logging.getLogger("uvicorn")

# ── Path to the ground-truth JSON ─────────────────────────────────────
_DATA_DIR = Path(__file__).resolve().parent.parent.parent / "data"
_QURAN_FILE = _DATA_DIR / "quran_uthmani.json"

# ── In-memory cache (loaded once at startup) ──────────────────────────
_quran_data: Optional[Dict] = None


def _load_quran_data() -> Dict:
    """Load the Quran JSON file into memory. Called once at startup."""
    global _quran_data
    if _quran_data is not None:
        return _quran_data

    if _QURAN_FILE.exists():
        with open(_QURAN_FILE, "r", encoding="utf-8") as f:
            _quran_data = json.load(f)
        logger.info(
            f"[QuranLoader] Loaded ground-truth data from {_QURAN_FILE} "
            f"({len(_quran_data.get('surahs', []))} surahs)"
        )
    else:
        logger.warning(
            f"[QuranLoader] {_QURAN_FILE} not found. "
            "Word lookup will return the expected_word from the client payload."
        )
        _quran_data = {"surahs": []}

    return _quran_data


def initialize():
    """Eagerly load Quran data into memory. Call during app startup."""
    _load_quran_data()


def remove_diacritics(text: str) -> str:
    """Remove Arabic diacritical marks (tashkeel) from text."""
    return re.sub(r"[\u064B-\u065F\u0670]", "", text)


def get_ayah_text(surah_num: int, ayah_num: int) -> Optional[str]:
    """
    Get the full Arabic text of a specific ayah.

    Args:
        surah_num: Surah number (1-114).
        ayah_num: Ayah number within the surah.

    Returns:
        The Arabic text of the ayah, or None if not found.
    """
    data = _load_quran_data()
    for surah in data.get("surahs", []):
        if surah.get("number") == surah_num:
            for ayah in surah.get("ayahs", []):
                if ayah.get("numberInSurah") == ayah_num:
                    return ayah.get("text", "")
    return None


def get_ayah_words(surah_num: int, ayah_num: int) -> List[Dict]:
    """
    Get the individual words of a specific ayah as a list of dicts.

    Each dict contains:
        - index (int): 0-based word position
        - arabic (str): The word in Arabic with diacritics
        - arabic_clean (str): The word without diacritics (for comparison)

    Args:
        surah_num: Surah number (1-114).
        ayah_num: Ayah number within the surah.

    Returns:
        List of word dictionaries, or an empty list if not found.
    """
    text = get_ayah_text(surah_num, ayah_num)
    if not text:
        return []

    raw_words = text.strip().split()
    words = []
    for i, w in enumerate(raw_words):
        words.append({
            "index": i,
            "arabic": w,
            "arabic_clean": remove_diacritics(w),
        })
    return words


def get_surah_word_count(surah_num: int) -> int:
    """Get the total number of words in a surah."""
    data = _load_quran_data()
    total = 0
    for surah in data.get("surahs", []):
        if surah.get("number") == surah_num:
            for ayah in surah.get("ayahs", []):
                text = ayah.get("text", "")
                total += len(text.strip().split())
            break
    return total
