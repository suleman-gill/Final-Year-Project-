"""
Tilawah AI — Audio Proxy & Caching Router.

Endpoint: GET /api/audio/word/{surah}/{ayah}/{word_index}

Acts as a reverse proxy to https://audio.qurancdn.com with local disk caching.
On first request, fetches the MP3 from QuranCDN, saves it locally under
backend/data/audio_cache/, and streams it to the client. Subsequent requests
are served directly from disk without hitting the CDN.
"""

import logging
from pathlib import Path

import httpx
from fastapi import APIRouter, HTTPException, Depends
from fastapi.responses import FileResponse

from app.core.security import get_current_user
from app.models.user import User

logger = logging.getLogger("uvicorn")
router = APIRouter(prefix="/api/audio", tags=["audio"])

# ── Cache directory ───────────────────────────────────────────────────
_CACHE_DIR = Path(__file__).resolve().parent.parent.parent / "data" / "audio_cache"
_CACHE_DIR.mkdir(parents=True, exist_ok=True)

# ── Upstream CDN ──────────────────────────────────────────────────────
_CDN_BASE = "https://audio.qurancdn.com"


def _cache_path(surah: int, ayah: int, word_index: int) -> Path:
    """
    Compute the local cache file path for a word audio clip.

    Structure: data/audio_cache/{surah}/{ayah}/{word_index}.mp3
    """
    directory = _CACHE_DIR / str(surah) / str(ayah)
    directory.mkdir(parents=True, exist_ok=True)
    return directory / f"{word_index}.mp3"

MAX_CACHE_SIZE_MB = 200

def _enforce_cache_limit():
    """Ensure the local audio cache doesn't exceed the specified limit."""
    try:
        files = [f for f in _CACHE_DIR.rglob('*') if f.is_file()]
        total_size = sum(f.stat().st_size for f in files)
        if total_size > MAX_CACHE_SIZE_MB * 1024 * 1024:
            logger.info(f"[Audio] Cache size {total_size / 1024 / 1024:.2f}MB exceeds limit. Pruning oldest files.")
            # Sort by modification time, oldest first
            files.sort(key=lambda f: f.stat().st_mtime)
            # Delete oldest half
            for f in files[:len(files)//2]:
                f.unlink(missing_ok=True)
    except Exception as e:
        logger.error(f"[Audio] Failed to enforce cache limit: {e}")


@router.get("/word/{surah}/{ayah}/{word_index}")
async def get_word_audio(
    surah: int, 
    ayah: int, 
    word_index: int,
    current_user: User = Depends(get_current_user),
):
    """
    Stream the word-by-word recitation audio for a specific word.

    1. Checks if the audio file exists in the local cache.
    2. If cached → streams it immediately from disk.
    3. If not cached → fetches from QuranCDN, saves locally, then streams.

    The CDN URL pattern is:
        https://audio.qurancdn.com/wbw/{surah}/{ayah}/{word_index}/Alafasy.mp3

    Args:
        surah: Surah number (1-114).
        ayah: Ayah number within the surah.
        word_index: 0-based word position within the ayah.
    """
    # ── Input validation ──────────────────────────────────────────────
    if not (1 <= surah <= 114):
        raise HTTPException(status_code=400, detail="Surah number must be between 1 and 114")
    if ayah < 1:
        raise HTTPException(status_code=400, detail="Ayah number must be >= 1")
    if word_index < 0:
        raise HTTPException(status_code=400, detail="Word index must be >= 0")

    cached_file = _cache_path(surah, ayah, word_index)

    # ── Serve from cache ──────────────────────────────────────────────
    if cached_file.exists() and cached_file.stat().st_size > 0:
        logger.debug(f"[Audio] Cache HIT: {surah}/{ayah}/{word_index}")
        return FileResponse(
            path=str(cached_file),
            media_type="audio/mpeg",
            filename=f"{surah}_{ayah}_{word_index}.mp3",
        )

    # ── Fetch from CDN ────────────────────────────────────────────────
    cdn_url = f"{_CDN_BASE}/wbw/{surah}/{ayah}/{word_index}/Alafasy.mp3"
    logger.info(f"[Audio] Cache MISS — fetching from CDN: {cdn_url}")

    try:
        async with httpx.AsyncClient(timeout=15.0, follow_redirects=True) as client:
            response = await client.get(cdn_url)

            if response.status_code == 404:
                raise HTTPException(
                    status_code=404,
                    detail=f"Audio not found on CDN for surah={surah}, ayah={ayah}, word={word_index}",
                )

            response.raise_for_status()

            # ── Save to local cache ───────────────────────────────────
            cached_file.write_bytes(response.content)
            logger.info(
                f"[Audio] Cached {len(response.content)} bytes → {cached_file}"
            )
            # Enforce limit after adding new file
            _enforce_cache_limit()

    except httpx.HTTPStatusError as e:
        logger.error(f"[Audio] CDN HTTP error: {e.response.status_code} for {cdn_url}")
        raise HTTPException(
            status_code=502,
            detail=f"Upstream CDN returned {e.response.status_code}",
        )
    except httpx.RequestError as e:
        logger.error(f"[Audio] CDN connection error: {e}")
        raise HTTPException(
            status_code=502,
            detail="Failed to connect to audio CDN. Please try again later.",
        )

    # ── Stream the freshly cached file ────────────────────────────────
    return FileResponse(
        path=str(cached_file),
        media_type="audio/mpeg",
        filename=f"{surah}_{ayah}_{word_index}.mp3",
    )
