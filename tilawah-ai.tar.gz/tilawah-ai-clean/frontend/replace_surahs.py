import sys

file_path = '/home/mfaisalm/Desktop/tilawah-ai/frontend/lib/services/quran_data_service.dart'
with open(file_path, 'r') as f:
    content = f.read()

with open('surahs_dart.txt', 'r') as f:
    surahs_text = f.read()

start_marker = "  static const List<SurahInfo> surahs = ["
end_marker = "  ];"

start_idx = content.find(start_marker)
if start_idx != -1:
    end_idx = content.find(end_marker, start_idx) + len(end_marker)
    content = content[:start_idx] + surahs_text + content[end_idx:]

with open(file_path, 'w') as f:
    f.write(content)

print("Done replacing surahs.")
