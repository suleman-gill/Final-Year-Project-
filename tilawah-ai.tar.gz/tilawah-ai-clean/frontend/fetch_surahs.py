import requests

try:
    res = requests.get('http://api.alquran.cloud/v1/surah')
    data = res.json()['data']
    print("  static const List<SurahInfo> surahs = [")
    for s in data:
        meaning = s['englishNameTranslation'].replace("'", "\\'")
        print(f"    SurahInfo(number: {s['number']}, nameArabic: '{s['name']}', nameEnglish: '{s['englishName']}', meaning: '{meaning}', verses: {s['numberOfAyahs']}, revelationType: '{s['revelationType']}'),")
    print("  ];")
except Exception as e:
    print(e)
