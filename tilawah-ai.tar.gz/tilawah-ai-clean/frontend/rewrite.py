import sys

file_path = '/home/mfaisalm/Desktop/tilawah-ai/frontend/lib/screens/recitation/recitation_screen.dart'
with open(file_path, 'r') as f:
    content = f.read()

# Replace import
content = content.replace("import 'package:just_audio/just_audio.dart';", "import 'package:just_audio/just_audio.dart';\nimport 'package:go_router/go_router.dart';")

# Replace fetch
content = content.replace("await QuranDataService.fetchAyahWords(currentSurah, currentAyah);", "await QuranDataService.fetchSurahWords(currentSurah);")

# Replace build
build_start = content.find("  @override\n  Widget build(BuildContext context) {")
build_end = content.find("class _ScoreChip extends StatelessWidget {")
if build_start != -1 and build_end != -1:
    new_build = """  @override
  Widget build(BuildContext context) {
    final surah = QuranDataService.surahMap[currentSurah] ?? QuranDataService.surahs.first;

    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        backgroundColor: AppColors.primary,
        elevation: 0,
        leading: IconButton(
          icon: Icon(Icons.arrow_back_rounded, color: AppColors.textLight),
          onPressed: () => context.pop(), // Go back
        ),
        title: Text(surah.nameEnglish, style: AppText.heading2(color: AppColors.textLight)),
        actions: [
          if (!_isConnected) 
            const Padding(
              padding: EdgeInsets.only(right: 16.0),
              child: SizedBox(
                width: 16, height: 16,
                child: CircularProgressIndicator(color: AppColors.gold, strokeWidth: 2),
              ),
            ),
          IconButton(
            icon: Icon(Icons.refresh_rounded, color: AppColors.textLight),
            onPressed: _reset,
          ),
        ],
      ),
      body: SafeArea(
        child: Column(
          children: [
            // Page Header card
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
              color: AppColors.surface,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text('Juz 1', style: AppText.caption(color: AppColors.textLight.withOpacity(0.7))),
                  Text(surah.nameArabic, style: AppText.arabicMedium.copyWith(color: AppColors.gold, fontSize: 18)),
                  Text('${surah.revelationType} • ${surah.verses} Verses', style: AppText.caption(color: AppColors.textLight.withOpacity(0.7))),
                ],
              ),
            ),

            // Continuous scrollable text
            Expanded(
              child: _words.isEmpty
                  ? const Center(child: CircularProgressIndicator(color: AppColors.gold))
                  : ListView(
                      padding: const EdgeInsets.all(20),
                      children: [
                        // Quran text card
                        Container(
                          padding: const EdgeInsets.all(24),
                          decoration: BoxDecoration(
                            color: AppColors.surface,
                            borderRadius: BorderRadius.circular(Dims.radius),
                            border: Border.all(color: AppColors.textLight.withOpacity(0.05)),
                          ),
                          child: Column(
                            children: [
                              // Bismillah
                              if (currentSurah != 9)
                                Padding(
                                  padding: const EdgeInsets.only(bottom: 24),
                                  child: Text(
                                    'بِسْمِ اللَّهِ الرَّحْمَنِ الرَّحِيم',
                                    textAlign: TextAlign.center,
                                    style: AppText.arabicLarge.copyWith(
                                      fontSize: 28,
                                      color: AppColors.textLight,
                                    ),
                                  ),
                                ),

                              // Justified continuous Arabic text
                              AnimatedBuilder(
                                animation: _pulseCtrl,
                                builder: (context, _) {
                                  return RichText(
                                    textAlign: TextAlign.justify,
                                    textDirection: TextDirection.rtl,
                                    text: TextSpan(
                                      style: AppText.arabicLarge.copyWith(
                                        color: AppColors.textLight,
                                        height: 2.2,
                                        fontSize: 24,
                                      ),
                                      children: _buildSpans(_pulseCtrl.value),
                                    ),
                                  );
                                },
                              ),
                            ],
                          ),
                        ),

                        // Session done summary card
                        if (_sessionDone) ...[
                          const SizedBox(height: 24),
                          Container(
                            padding: const EdgeInsets.all(20),
                            decoration: BoxDecoration(
                              color: AppColors.surface,
                              borderRadius: BorderRadius.circular(Dims.radius),
                              border: Border.all(color: AppColors.textLight.withOpacity(0.05)),
                            ),
                            child: Column(
                              children: [
                                const Icon(Icons.check_circle_rounded, color: AppColors.correct, size: 48),
                                const SizedBox(height: 10),
                                Text('Recitation Complete!', style: AppText.heading2(color: AppColors.textLight)),
                                const SizedBox(height: 6),
                                if (_sessionMessage != null)
                                  Text(
                                    _sessionMessage!,
                                    textAlign: TextAlign.center,
                                    style: AppText.body(color: AppColors.gold),
                                  ),
                                const SizedBox(height: 16),
                                ElevatedButton.icon(
                                  onPressed: _reset,
                                  icon:  const Icon(Icons.replay_rounded),
                                  label: const Text('Try Again'),
                                  style: ElevatedButton.styleFrom(
                                    backgroundColor: AppColors.gold,
                                    foregroundColor: AppColors.primary,
                                    padding: const EdgeInsets.symmetric(horizontal: 28, vertical: 14),
                                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                        
                        // Tajweed tip
                        if (_currentTajweedTip != null && !_sessionDone) ...[
                          const SizedBox(height: 24),
                          Container(
                            padding: const EdgeInsets.all(16),
                            decoration: BoxDecoration(
                              color: AppColors.emerald.withOpacity(0.06),
                              borderRadius: BorderRadius.circular(Dims.radius),
                              border: Border.all(color: AppColors.emerald.withOpacity(0.12)),
                            ),
                            child: Row(
                              children: [
                                const Icon(Icons.lightbulb_outline_rounded, color: AppColors.gold, size: 20),
                                const SizedBox(width: 10),
                                Expanded(
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Text(
                                        'Tajweed Hint',
                                        style: AppText.caption(color: AppColors.gold).copyWith(fontWeight: FontWeight.w700),
                                      ),
                                      const SizedBox(height: 4),
                                      Text(_currentTajweedTip!, style: AppText.body(color: AppColors.textLight)),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                        
                        const SizedBox(height: 100), // padding for bottom mic bar
                      ],
                    ),
            ),
          ],
        ),
      ),

      bottomNavigationBar: Container(
        padding: EdgeInsets.only(
          left: 24,
          right: 24,
          top: 20,
          bottom: MediaQuery.of(context).padding.bottom + 16,
        ),
        decoration: BoxDecoration(
          color: AppColors.surface,
          border: Border(top: BorderSide(color: AppColors.textLight.withOpacity(0.1))),
          boxShadow: [
            BoxShadow(
              color: AppColors.background.withOpacity(0.5),
              blurRadius: 10,
              offset: const Offset(0, -4),
            )
          ],
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            if (!_sessionDone)
              Text(
                _isListening ? 'Listening... Recite clearly' : 'Tap mic & recite continuously',
                style: AppText.caption(color: _isListening ? AppColors.incorrect : AppColors.textMuted),
              ),
            const SizedBox(height: 14),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                _RoundBtn(
                  icon: Icons.play_arrow_rounded,
                  color: AppColors.emerald,
                  onTap: _playReferenceAudio,
                ),
                const SizedBox(width: 20),
                AnimatedBuilder(
                  animation: _pulseCtrl,
                  builder: (_, __) => GestureDetector(
                    onTap: _sessionDone ? null : _toggleRecording,
                    child: Container(
                      width: 72, height: 72,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: _isListening ? AppColors.incorrect : AppColors.gold,
                        boxShadow: [
                          BoxShadow(
                            color: (_isListening ? AppColors.incorrect : AppColors.gold)
                                .withOpacity(0.35 + _pulseCtrl.value * 0.15),
                            blurRadius: 20 + _pulseCtrl.value * 8,
                            spreadRadius: 2,
                          ),
                        ],
                      ),
                      child: Icon(
                        _isListening ? Icons.stop_rounded : Icons.mic_rounded,
                        color: AppColors.primary,
                        size: 32,
                      ),
                    ),
                  ),
                ),
                const SizedBox(width: 20),
                _RoundBtn(
                  icon: Icons.skip_next_rounded,
                  color: AppColors.textMuted,
                  onTap: _skip,
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

"""
    content = content[:build_start] + new_build + content[build_end:]

with open(file_path, 'w') as f:
    f.write(content)
print("Done")
