import sys

# 1. Update QuranReaderScreen
file_path = '/home/mfaisalm/Desktop/tilawah-ai/frontend/lib/screens/quran/quran_reader_screen.dart'
with open(file_path, 'r') as f:
    content = f.read()

import_stmt = "import '../../widgets/quran/mushaf_page_frame.dart';\n"
if import_stmt not in content:
    content = content.replace("import '../../services/quran_data_service.dart';", "import '../../services/quran_data_service.dart';\n" + import_stmt)

target = """                  // Quran text card
                  Container(
                    padding: const EdgeInsets.all(24),
                    decoration: BoxDecoration(
                      color: AppColors.surface,
                      borderRadius: BorderRadius.circular(Dims.radius),
                      border: Border.all(color: AppColors.textLight.withOpacity(0.05)),
                    ),
                    child: Column(
                      children: [
                        // Bismillah
                        if (widget.surahNumber != 9)
                          Padding(
                            padding: const EdgeInsets.only(bottom: 24),
                            child: Text(
                              'بِسْمِ اللَّهِ الرَّحْمَنِ الرَّحِيم',
                              textAlign: TextAlign.center,
                              style: AppText.arabicLarge.copyWith(
                                fontSize: 28 * _fontSizeMultiplier,
                                color: AppColors.textLight,
                              ),
                            ),
                          ),

                        // Justified continuous Arabic text
                        RichText(
                          textAlign: TextAlign.justify,
                          textDirection: TextDirection.rtl,
                          text: TextSpan(
                            style: AppText.arabicLarge.copyWith(
                              color: AppColors.textLight,
                              height: 2.2,
                              fontSize: 24 * _fontSizeMultiplier,
                            ),
                            children: spans,
                          ),
                        ),
                      ],
                    ),
                  ),"""

replacement = """                  // Quran text card
                  MushafPageFrame(
                    child: Container(
                      padding: const EdgeInsets.all(16),
                      child: Column(
                        children: [
                          // Bismillah
                          if (widget.surahNumber != 9)
                            Padding(
                              padding: const EdgeInsets.only(bottom: 24, top: 8),
                              child: Text(
                                'بِسْمِ اللَّهِ الرَّحْمَنِ الرَّحِيم',
                                textAlign: TextAlign.center,
                                style: AppText.arabicLarge.copyWith(
                                  fontSize: 28 * _fontSizeMultiplier,
                                  color: AppColors.textLight,
                                ),
                              ),
                            ),

                          // Justified continuous Arabic text
                          RuledBackground(
                            lineHeight: (24 * _fontSizeMultiplier) * 2.2,
                            offsetTop: (24 * _fontSizeMultiplier) * 2.2 * 0.75,
                            child: RichText(
                              textAlign: TextAlign.justify,
                              textDirection: TextDirection.rtl,
                              text: TextSpan(
                                style: AppText.arabicLarge.copyWith(
                                  color: AppColors.textLight,
                                  height: 2.2,
                                  fontSize: 24 * _fontSizeMultiplier,
                                ),
                                children: spans,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),"""

content = content.replace(target, replacement)
with open(file_path, 'w') as f:
    f.write(content)


# 2. Update RecitationScreen
file_path2 = '/home/mfaisalm/Desktop/tilawah-ai/frontend/lib/screens/recitation/recitation_screen.dart'
with open(file_path2, 'r') as f:
    content2 = f.read()

import_stmt2 = "import '../../widgets/quran/mushaf_page_frame.dart';\n"
if import_stmt2 not in content2:
    content2 = content2.replace("import '../../services/quran_data_service.dart';", "import '../../services/quran_data_service.dart';\n" + import_stmt2)

target2 = """                        // Quran text card
                        Container(
                          padding: const EdgeInsets.all(24),
                          decoration: BoxDecoration(
                            color: AppColors.surface,
                            borderRadius: BorderRadius.circular(Dims.radius),
                            border: Border.all(color: AppColors.textLight.withOpacity(0.05)),
                          ),
                          child: Column(
                            children: [
                              // Bismillah
                              if (currentSurah != 9)
                                Padding(
                                  padding: const EdgeInsets.only(bottom: 24),
                                  child: Text(
                                    'بِسْمِ اللَّهِ الرَّحْمَنِ الرَّحِيم',
                                    textAlign: TextAlign.center,
                                    style: AppText.arabicLarge.copyWith(
                                      fontSize: 28,
                                      color: AppColors.textLight,
                                    ),
                                  ),
                                ),

                              // Justified continuous Arabic text
                              AnimatedBuilder(
                                animation: _pulseCtrl,
                                builder: (context, _) {
                                  return RichText(
                                    textAlign: TextAlign.justify,
                                    textDirection: TextDirection.rtl,
                                    text: TextSpan(
                                      style: AppText.arabicLarge.copyWith(
                                        color: AppColors.textLight,
                                        height: 2.2,
                                        fontSize: 24,
                                      ),
                                      children: _buildSpans(_pulseCtrl.value),
                                    ),
                                  );
                                },
                              ),
                            ],
                          ),
                        ),"""

replacement2 = """                        // Quran text card
                        MushafPageFrame(
                          child: Container(
                            padding: const EdgeInsets.all(16),
                            child: Column(
                              children: [
                                // Bismillah
                                if (currentSurah != 9)
                                  Padding(
                                    padding: const EdgeInsets.only(bottom: 24, top: 8),
                                    child: Text(
                                      'بِسْمِ اللَّهِ الرَّحْمَنِ الرَّحِيم',
                                      textAlign: TextAlign.center,
                                      style: AppText.arabicLarge.copyWith(
                                        fontSize: 28,
                                        color: AppColors.textLight,
                                      ),
                                    ),
                                  ),

                                // Justified continuous Arabic text
                                AnimatedBuilder(
                                  animation: _pulseCtrl,
                                  builder: (context, _) {
                                    return RuledBackground(
                                      lineHeight: 24 * 2.2,
                                      offsetTop: 24 * 2.2 * 0.75,
                                      child: RichText(
                                        textAlign: TextAlign.justify,
                                        textDirection: TextDirection.rtl,
                                        text: TextSpan(
                                          style: AppText.arabicLarge.copyWith(
                                            color: AppColors.textLight,
                                            height: 2.2,
                                            fontSize: 24,
                                          ),
                                          children: _buildSpans(_pulseCtrl.value),
                                        ),
                                      ),
                                    );
                                  },
                                ),
                              ],
                            ),
                          ),
                        ),"""

content2 = content2.replace(target2, replacement2)
with open(file_path2, 'w') as f:
    f.write(content2)

print("Done replacing.")
