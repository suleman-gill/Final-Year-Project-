import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import '../../config/theme.dart';
import '../../services/quran_data_service.dart';
import '../../widgets/quran/mushaf_page_frame.dart';

import '../../core/storage/hive_storage.dart';

class QuranReaderScreen extends StatefulWidget {
  final int surahNumber;
  const QuranReaderScreen({super.key, required this.surahNumber});

  @override
  State<QuranReaderScreen> createState() => _QuranReaderScreenState();
}

class _QuranReaderScreenState extends State<QuranReaderScreen> {
  double _fontSizeMultiplier = 1.0;
  bool _showTranslations = true;
  bool _isBookmarked = false;

  @override
  void initState() {
    super.initState();
    _fontSizeMultiplier = HiveStorage.getFontSizeMultiplier();
    _isBookmarked = HiveStorage.isBookmarked(widget.surahNumber);
  }

  String _toArabicNumerals(int number) {
    const digits = ['٠', '١', '٢', '٣', '٤', '٥', '٦', '٧', '٨', '٩'];
    return number.toString().split('').map((e) => digits[int.parse(e)]).join('');
  }

  void _toggleBookmark() {
    HiveStorage.toggleBookmark(widget.surahNumber);
    setState(() {
      _isBookmarked = !_isBookmarked;
    });
    
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(_isBookmarked ? "Surah added to bookmarks." : "Surah removed from bookmarks."),
        backgroundColor: AppColors.emerald,
        duration: const Duration(seconds: 1),
      ),
    );
  }

  void _updateFontSize(double val) {
    HiveStorage.setFontSizeMultiplier(val);
    setState(() {
      _fontSizeMultiplier = val;
    });
  }

  @override
  Widget build(BuildContext context) {
    final surah = QuranDataService.surahMap[widget.surahNumber] ?? QuranDataService.surahs.first;
    final ayahs = QuranDataService.getAyahs(widget.surahNumber);

    // Build justified continuous spans
    final List<InlineSpan> spans = [];
    for (int i = 0; i < ayahs.length; i++) {
      spans.add(TextSpan(text: ayahs[i].arabic));
      spans.add(TextSpan(
        text: ' ﴿${_toArabicNumerals(i + 1)}﴾ ',
        style: TextStyle(color: AppColors.gold, fontSize: 22 * _fontSizeMultiplier),
      ));
    }

    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        backgroundColor: AppColors.primary,
        elevation: 0,
        leading: IconButton(
          icon: Icon(Icons.arrow_back_rounded, color: AppColors.textLight),
          onPressed: () => context.go('/quran'),
        ),
        title: Text(surah.nameEnglish, style: AppText.heading2(color: AppColors.textLight)),
        actions: [
          IconButton(
            icon: Icon(
              _showTranslations ? Icons.translate_rounded : Icons.g_translate_rounded,
              color: _showTranslations ? AppColors.gold : AppColors.textLight.withOpacity(0.7),
            ),
            onPressed: () => setState(() => _showTranslations = !_showTranslations),
          ),
          IconButton(
            icon: Icon(
              _isBookmarked ? Icons.bookmark_rounded : Icons.bookmark_border_rounded,
              color: AppColors.gold,
            ),
            onPressed: _toggleBookmark,
          ),
        ],
      ),
      body: SafeArea(
        child: Column(
          children: [
            // Page Header card
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
              color: AppColors.surface,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text('Juz 1', style: AppText.caption(color: AppColors.textLight.withOpacity(0.7))),
                  Text(surah.nameArabic, style: AppText.arabicMedium.copyWith(color: AppColors.gold, fontSize: 18)),
                  Text('${surah.revelationType} • ${surah.verses} Verses', style: AppText.caption(color: AppColors.textLight.withOpacity(0.7))),
                ],
              ),
            ),

            // Continuous scrollable text
            Expanded(
              child: ListView(
                padding: const EdgeInsets.all(20),
                children: [
                  // Quran text card
                  MushafPageFrame(
                    child: Container(
                      padding: const EdgeInsets.all(16),
                      child: Column(
                        children: [
                          // Bismillah
                          if (widget.surahNumber != 9)
                            Padding(
                              padding: const EdgeInsets.only(bottom: 24, top: 8),
                              child: Text(
                                'بِسْمِ اللَّهِ الرَّحْمَنِ الرَّحِيم',
                                textAlign: TextAlign.center,
                                style: AppText.arabicLarge.copyWith(
                                  fontSize: 28 * _fontSizeMultiplier,
                                  color: AppColors.textLight,
                                ),
                              ),
                            ),

                          // Justified continuous Arabic text
                          RuledBackground(
                            lineHeight: (24 * _fontSizeMultiplier) * 2.2,
                            offsetTop: (24 * _fontSizeMultiplier) * 2.2 * 0.75,
                            child: RichText(
                              textAlign: TextAlign.justify,
                              textDirection: TextDirection.rtl,
                              text: TextSpan(
                                style: AppText.arabicLarge.copyWith(
                                  color: AppColors.textLight,
                                  height: 2.2,
                                  fontSize: 24 * _fontSizeMultiplier,
                                ),
                                children: spans,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),

                  // English translations block
                  if (_showTranslations) ...[
                    const SizedBox(height: 24),
                    Text("Translations", style: AppText.heading3()),
                    const SizedBox(height: 12),
                    ...List.generate(ayahs.length, (i) {
                      return Container(
                        margin: const EdgeInsets.only(bottom: 12),
                        padding: const EdgeInsets.all(16),
                        decoration: BoxDecoration(
                          color: AppColors.surface,
                          borderRadius: BorderRadius.circular(Dims.radius),
                          border: Border.all(color: AppColors.textLight.withOpacity(0.03)),
                        ),
                        child: Row(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Container(
                              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                              decoration: BoxDecoration(
                                color: AppColors.gold.withOpacity(0.1),
                                borderRadius: BorderRadius.circular(8),
                              ),
                              child: Text(
                                '${i + 1}',
                                style: const TextStyle(color: AppColors.gold, fontWeight: FontWeight.bold, fontSize: 12),
                              ),
                            ),
                            const SizedBox(width: 14),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    ayahs[i].translation,
                                    style: AppText.body(color: AppColors.textLight.withOpacity(0.85)),
                                  ),
                                  const SizedBox(height: 6),
                                  Text(
                                    "English - Sahih International",
                                    style: AppText.caption(),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      );
                    }),
                  ],
                ],
              ),
            ),

            // Font adjustment bottom bar
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
              color: AppColors.primary,
              child: Row(
                children: [
                  const Icon(Icons.format_size_rounded, color: AppColors.gold, size: 20),
                  const SizedBox(width: 12),
                  Expanded(
                    child: SliderTheme(
                      data: SliderTheme.of(context).copyWith(
                        activeTrackColor: AppColors.gold,
                        inactiveTrackColor: AppColors.textLight.withOpacity(0.12),
                        thumbColor: AppColors.gold,
                        overlayColor: AppColors.gold.withOpacity(0.2),
                      ),
                      child: Slider(
                        value: _fontSizeMultiplier,
                        min: 0.7,
                        max: 1.5,
                        divisions: 8,
                        onChanged: _updateFontSize,
                      ),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Text(
                    "${(_fontSizeMultiplier * 100).round()}%",
                    style: TextStyle(color: AppColors.textLight, fontWeight: FontWeight.bold),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => context.go('/recitation?surahNum=${widget.surahNumber}'),
        backgroundColor: AppColors.emerald,
        icon: const Icon(Icons.mic_rounded, color: Colors.white),
        label: const Text('Recite', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
      ),
    );
  }
}
