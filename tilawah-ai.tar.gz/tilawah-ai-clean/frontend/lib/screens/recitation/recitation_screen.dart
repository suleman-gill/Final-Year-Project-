import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'dart:convert';
import 'dart:async';
import 'dart:typed_data';
import 'dart:io';
import 'package:flutter/foundation.dart' show kIsWeb;
import 'package:dio/dio.dart';
import 'package:record/record.dart';
import 'package:just_audio/just_audio.dart';
import 'package:go_router/go_router.dart';
import '../../config/theme.dart';
import '../../features/auth/auth_notifier.dart';
import '../../features/recitation/recitation_engine.dart';
import '../../services/quran_data_service.dart';
import '../../widgets/quran/mushaf_page_frame.dart';
import 'recitation_results_screen.dart';

import '../../widgets/common/app_header.dart';

// ── Verse grouping helper ────────────────────────────────────────────
class _VerseInfo {
  final int ayahNumber; // 1-based within surah
  final List<int> wordIndices; // indices into flat word list (real words only)
  final int? markerIndex; // index of ﴿N﴾ in flat word list

  const _VerseInfo({
    required this.ayahNumber,
    required this.wordIndices,
    this.markerIndex,
  });
}

class RecitationScreen extends ConsumerStatefulWidget {
  final int? surahNum;
  final int? ayahNum;

  const RecitationScreen({super.key, this.surahNum, this.ayahNum});

  @override
  ConsumerState<RecitationScreen> createState() => _RecitationScreenState();
}

class _RecitationScreenState extends ConsumerState<RecitationScreen>
    with SingleTickerProviderStateMixin {
  // ── Word & verse data ──────────────────────────────────────────────
  List<AyahWord> _allWords = [];
  late List<WordStatus> _statuses;
  List<_VerseInfo> _verses = [];
  int _currentVerseIdx = 0;

  // ── Scoring ────────────────────────────────────────────────────────
  int _correctCount = 0;
  int _wrongCount = 0;

  // ── Recording state ────────────────────────────────────────────────
  bool _isRecording = false;
  bool _isProcessing = false;
  bool _sessionDone = false;
  String? _currentTajweedTip;

  // ── Audio ──────────────────────────────────────────────────────────
  final AudioRecorder _audioRecorder = AudioRecorder();
  final AudioPlayer _audioPlayer = AudioPlayer();

  // ── Results collection ─────────────────────────────────────────────
  final List<WordResult> _collectedResults = [];

  // ── Engine ─────────────────────────────────────────────────────────
  late RecitationInferenceEngine _engine;
  StreamSubscription<VerseInferenceResult>? _verseResultSub;
  StreamSubscription<WsConnectionState>? _connectionSub;
  WsConnectionState _connectionState = WsConnectionState.disconnected;

  // ── Animation ──────────────────────────────────────────────────────
  late final AnimationController _pulseCtrl;

  int get currentSurah => widget.surahNum ?? 1;
  int get currentAyah => widget.ayahNum ?? 1;

  @override
  void initState() {
    super.initState();
    _pulseCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 900),
    )..repeat(reverse: true);

    _engine = WebSocketInferenceEngine();
    _loadWordsAndInit();
  }

  Future<void> _loadWordsAndInit() async {
    final words = await QuranDataService.fetchSurahWords(currentSurah);
    setState(() {
      _allWords = words;
      _statuses = List.filled(_allWords.length, WordStatus.pending);
      _parseVerses();
    });

    // Listen for verse-level results
    _verseResultSub = _engine.verseResults.listen((result) {
      if (mounted) _handleVerseResult(result);
    });

    // Listen for connection state
    _connectionSub = _engine.connectionStates.listen((state) {
      if (mounted) {
        setState(() => _connectionState = state);
        if (state == WsConnectionState.disconnected && _isRecording) {
          _cancelRecording();
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(
              content: Text("Connection lost. Please try again."),
              backgroundColor: AppColors.incorrect,
            ),
          );
        }
      }
    });

    // Initialize engine with auth token
    final token =
        await ref.read(authProvider.notifier).getFreshToken() ?? '';
    await _engine.initialize(token);

    // Start session
    final wordMaps = List.generate(_allWords.length, (i) => {
      'index': i,
      'arabic': _allWords[i].arabic,
      'phonetic': _allWords[i].phonetic,
    });
    await _engine.startSession(currentSurah, currentAyah, wordMaps);
  }

  /// Parse the flat word list into verse groups.
  /// Verse markers (﴿N﴾) delimit verses.
  void _parseVerses() {
    _verses = [];
    List<int> currentWords = [];
    int ayahNum = 1;

    for (int i = 0; i < _allWords.length; i++) {
      final text = _allWords[i].arabic;
      if (text.startsWith('﴿') && text.endsWith('﴾')) {
        if (currentWords.isNotEmpty) {
          _verses.add(_VerseInfo(
            ayahNumber: ayahNum,
            wordIndices: List.from(currentWords),
            markerIndex: i,
          ));
          ayahNum++;
          currentWords = [];
        }
      } else {
        currentWords.add(i);
      }
    }
    // Handle trailing words without marker
    if (currentWords.isNotEmpty) {
      _verses.add(_VerseInfo(
        ayahNumber: ayahNum,
        wordIndices: List.from(currentWords),
      ));
    }
  }

  @override
  void dispose() {
    _pulseCtrl.dispose();
    _cancelRecording();
    _audioRecorder.dispose();
    _audioPlayer.dispose();
    _verseResultSub?.cancel();
    _connectionSub?.cancel();
    _engine.dispose();
    super.dispose();
  }

  // ═══════════════════════════════════════════════════════════════════
  // RECORDING — verse-level
  // ═══════════════════════════════════════════════════════════════════

  Future<void> _toggleRecording() async {
    if (_isProcessing || _sessionDone) return;
    if (_isRecording) {
      await _stopAndSendVerse();
    } else {
      await _startRecording();
    }
  }

  Future<void> _startRecording() async {
    if (_connectionState != WsConnectionState.connected) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            _connectionState == WsConnectionState.reconnecting
                ? "Reconnecting to server..."
                : "Connecting to server... Please wait.",
          ),
          backgroundColor: AppColors.gold,
        ),
      );
      return;
    }

    try {
      if (await _audioRecorder.hasPermission()) {
        setState(() {
          _isRecording = true;
        });

        // Use AudioEncoder.wav for cross-platform compatibility
        await _audioRecorder.start(
          const RecordConfig(
            encoder: AudioEncoder.wav,
            sampleRate: 16000,
            numChannels: 1,
          ),
          path: '', // empty path on web generates a local blob URL
        );
      }
    } catch (e) {
      debugPrint("Error starting record: $e");
      setState(() => _isRecording = false);
    }
  }

  Future<void> _stopAndSendVerse() async {
    try {
      final path = await _audioRecorder.stop();
      setState(() {
        _isRecording = false;
        _isProcessing = true;
      });

      if (path == null) {
        setState(() => _isProcessing = false);
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(
              content: Text("No audio recorded. Try again."),
              backgroundColor: AppColors.incorrect,
            ),
          );
        }
        return;
      }

      // Read audio bytes
      Uint8List bytes;
      if (kIsWeb) {
        final response = await Dio().get<List<int>>(
          path,
          options: Options(responseType: ResponseType.bytes),
        );
        bytes = Uint8List.fromList(response.data!);
      } else {
        bytes = await File(path).readAsBytes();
      }

      if (bytes.isEmpty) {
        setState(() => _isProcessing = false);
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(
              content: Text("Recorded audio is empty. Try again."),
              backgroundColor: AppColors.incorrect,
            ),
          );
        }
        return;
      }

      // Gather expected words for the current verse
      final verse = _verses[_currentVerseIdx];
      final expectedWords =
          verse.wordIndices.map((i) => _allWords[i].arabic).toList();

      final base64Audio = base64Encode(bytes);

      // Send verse audio to backend
      _engine.sendVerseAudio(base64Audio, _currentVerseIdx, expectedWords);

      // Timeout: if no result in 30s, cancel processing
      Future.delayed(const Duration(seconds: 30), () {
        if (mounted && _isProcessing) {
          setState(() => _isProcessing = false);
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(
              content: Text("Processing timed out. Please try again."),
              backgroundColor: AppColors.incorrect,
            ),
          );
        }
      });
    } catch (e) {
      debugPrint("Error stopping record: $e");
      setState(() {
        _isRecording = false;
        _isProcessing = false;
      });
    }
  }

  /// Cancel recording without sending (e.g. on disconnect)
  Future<void> _cancelRecording() async {
    try {
      await _audioRecorder.stop();
      if (mounted) {
        setState(() {
          _isRecording = false;
          _isProcessing = false;
        });
      }
    } catch (_) {}
  }

  // ═══════════════════════════════════════════════════════════════════
  // RESULT HANDLING
  // ═══════════════════════════════════════════════════════════════════

  void _handleVerseResult(VerseInferenceResult result) {
    if (_sessionDone || result.verseIndex != _currentVerseIdx) return;
    if (_currentVerseIdx >= _verses.length) return;

    final verse = _verses[_currentVerseIdx];

    setState(() {
      _isProcessing = false;

      // Color each word based on results
      for (int i = 0;
          i < result.wordResults.length && i < verse.wordIndices.length;
          i++) {
        final wordIdx = verse.wordIndices[i];
        final wr = result.wordResults[i];

        _statuses[wordIdx] =
            wr.isCorrect ? WordStatus.correct : WordStatus.incorrect;

        if (wr.isCorrect) {
          _correctCount++;
        } else {
          _wrongCount++;
        }

        _collectedResults.add(WordResult(
          arabic: _allWords[wordIdx].arabic,
          isCorrect: wr.isCorrect,
          errorType: wr.errorType,
          tajweedTip: wr.tajweedTip,
          confidence: wr.confidence,
        ));
      }

      // Mark verse marker as completed
      if (verse.markerIndex != null) {
        _statuses[verse.markerIndex!] = WordStatus.correct;
      }

      // Show tajweed tip for first error
      final firstError = result.wordResults
          .where((w) => !w.isCorrect && w.tajweedTip != null)
          .toList();
      _currentTajweedTip =
          firstError.isNotEmpty ? firstError.first.tajweedTip : null;
    });

    // Auto-advance after a short delay
    Future.delayed(const Duration(seconds: 2), () {
      if (!mounted || _sessionDone) return;
      _advanceToNextVerse();
    });
  }

  void _advanceToNextVerse() {
    if (_currentVerseIdx < _verses.length - 1) {
      setState(() {
        _currentVerseIdx++;
        _currentTajweedTip = null;
      });
    } else {
      _endSession();
    }
  }

  void _skipVerse() {
    if (_isRecording) {
      _cancelRecording();
    }
    if (_currentVerseIdx < _verses.length) {
      final verse = _verses[_currentVerseIdx];
      setState(() {
        for (final idx in verse.wordIndices) {
          _statuses[idx] = WordStatus.incorrect;
          _wrongCount++;
          _collectedResults.add(WordResult(
            arabic: _allWords[idx].arabic,
            isCorrect: false,
            errorType: 'Skipped',
            tajweedTip: null,
            confidence: 0.0,
          ));
        }
        if (verse.markerIndex != null) {
          _statuses[verse.markerIndex!] = WordStatus.incorrect;
        }
      });
      if (_currentVerseIdx < _verses.length - 1) {
        setState(() {
          _currentVerseIdx++;
          _currentTajweedTip = null;
        });
      } else {
        _endSession();
      }
    }
  }

  Future<void> _endSession() async {
    await _cancelRecording();
    setState(() => _sessionDone = true);

    try {
      await _engine.endSession();
    } catch (e) {
      debugPrint('Error ending session: $e');
    }

    if (mounted) {
      context.push(
        '/recitation/results',
        extra: {
          'surahNum': currentSurah,
          'ayahNum': currentAyah,
          'wordResults': List<WordResult>.from(_collectedResults),
          'correctCount': _correctCount,
          'wrongCount': _wrongCount,
          'totalWords': _collectedResults.length,
        },
      );
    }
  }

  void _reset() async {
    await _cancelRecording();
    setState(() {
      _statuses = List.filled(_allWords.length, WordStatus.pending);
      _currentVerseIdx = 0;
      _correctCount = 0;
      _wrongCount = 0;
      _sessionDone = false;
      _currentTajweedTip = null;
      _isProcessing = false;
      _collectedResults.clear();
    });

    final token =
        await ref.read(authProvider.notifier).getFreshToken() ?? '';
    await _engine.dispose();
    _engine = WebSocketInferenceEngine();

    _verseResultSub?.cancel();
    _connectionSub?.cancel();
    _verseResultSub = _engine.verseResults.listen((result) {
      if (mounted) _handleVerseResult(result);
    });
    _connectionSub = _engine.connectionStates.listen((state) {
      if (mounted) setState(() => _connectionState = state);
    });

    await _engine.initialize(token);
    final wordMaps = List.generate(_allWords.length, (i) => {
      'index': i,
      'arabic': _allWords[i].arabic,
      'phonetic': _allWords[i].phonetic,
    });
    await _engine.startSession(currentSurah, currentAyah, wordMaps);
  }

  // ═══════════════════════════════════════════════════════════════════
  // REFERENCE AUDIO — plays current verse
  // ═══════════════════════════════════════════════════════════════════

  Future<void> _playReferenceAudio() async {
    try {
      int verseNum = 1;
      if (_currentVerseIdx < _verses.length) {
        verseNum = _verses[_currentVerseIdx].ayahNumber;
      }
      String sNum = currentSurah.toString().padLeft(3, '0');
      String aNum = verseNum.toString().padLeft(3, '0');
      String url =
          "https://everyayah.com/data/Alafasy_128kbps/$sNum$aNum.mp3";
      await _audioPlayer.setUrl(url);
      _audioPlayer.play();
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text("Could not play audio: $e")),
        );
      }
    }
  }

  // ═══════════════════════════════════════════════════════════════════
  // UI — Span builder
  // ═══════════════════════════════════════════════════════════════════

  /// Determine which verse a word index belongs to.
  /// Returns -1 if it's a marker or not found.
  int _verseOfWord(int wordIdx) {
    for (int v = 0; v < _verses.length; v++) {
      if (_verses[v].wordIndices.contains(wordIdx)) return v;
      if (_verses[v].markerIndex == wordIdx) return v;
    }
    return -1;
  }

  List<InlineSpan> _buildSpans() {
    return List.generate(_allWords.length, (i) {
      final verseIdx = _verseOfWord(i);
      final isCurrentVerse = verseIdx == _currentVerseIdx && !_sessionDone;
      final isMarker = _allWords[i].arabic.startsWith('﴿');
      Color textColor;

      switch (_statuses[i]) {
        case WordStatus.correct:
          textColor = AppColors.correct;
          break;
        case WordStatus.incorrect:
          textColor = AppColors.incorrect;
          break;
        case WordStatus.pending:
        default:
          if (isMarker) {
            textColor = AppColors.textLight.withOpacity(0.4);
          } else if (isCurrentVerse) {
            textColor = AppColors.gold;
          } else {
            textColor = AppColors.textLight.withOpacity(0.5);
          }
      }

      return TextSpan(
        text: '${_allWords[i].arabic} ',
        style: TextStyle(
          color: textColor,
          fontWeight: isCurrentVerse && !isMarker
              ? FontWeight.bold
              : FontWeight.normal,
        ),
      );
    });
  }

  // ═══════════════════════════════════════════════════════════════════
  // BUILD
  // ═══════════════════════════════════════════════════════════════════

  @override
  Widget build(BuildContext context) {
    final surah = QuranDataService.surahMap[currentSurah] ??
        QuranDataService.surahs.first;

    // Current verse info label
    String verseLabel = '';
    if (_verses.isNotEmpty && _currentVerseIdx < _verses.length) {
      verseLabel =
          'Verse ${_verses[_currentVerseIdx].ayahNumber} of ${_verses.length}';
    }

    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        backgroundColor: AppColors.primary,
        elevation: 0,
        leading: IconButton(
          icon: Icon(Icons.arrow_back_rounded,
              color: AppColors.textLight),
          onPressed: () => context.pop(),
        ),
        title: Text(surah.nameEnglish,
            style: AppText.heading2(color: AppColors.textLight)),
        actions: [
          if (_connectionState != WsConnectionState.connected)
            Padding(
              padding: const EdgeInsets.only(right: 16.0),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  if (_connectionState == WsConnectionState.reconnecting)
                    Text('Reconnecting...',
                        style:
                            AppText.caption(color: AppColors.gold)),
                  const SizedBox(width: 6),
                  const SizedBox(
                    width: 16,
                    height: 16,
                    child: CircularProgressIndicator(
                        color: AppColors.gold, strokeWidth: 2),
                  ),
                ],
              ),
            ),
          IconButton(
            icon:
                Icon(Icons.refresh_rounded, color: AppColors.textLight),
            onPressed: _reset,
          ),
        ],
      ),
      body: SafeArea(
        child: Column(
          children: [
            // Page Header
            Container(
              padding: const EdgeInsets.symmetric(
                  horizontal: 16, vertical: 10),
              color: AppColors.surface,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(verseLabel,
                      style: AppText.caption(
                          color: AppColors.textLight.withOpacity(0.7))),
                  Text(surah.nameArabic,
                      style: AppText.arabicMedium
                          .copyWith(color: AppColors.gold, fontSize: 18)),
                  Text(
                      '${surah.revelationType} • ${surah.verses} Verses',
                      style: AppText.caption(
                          color: AppColors.textLight.withOpacity(0.7))),
                ],
              ),
            ),

            // Continuous scrollable text
            Expanded(
              child: _allWords.isEmpty
                  ? const Center(
                      child: CircularProgressIndicator(
                          color: AppColors.gold))
                  : ListView(
                      padding: const EdgeInsets.all(20),
                      children: [
                        MushafPageFrame(
                          child: Container(
                            padding: const EdgeInsets.all(16),
                            child: Column(
                              children: [
                                RuledBackground(
                                  lineHeight: 24 * 2.2,
                                  offsetTop: 24 * 2.2 * 0.75,
                                  child: RichText(
                                    textAlign: TextAlign.justify,
                                    textDirection: TextDirection.rtl,
                                    text: TextSpan(
                                      style:
                                          AppText.arabicLarge.copyWith(
                                        color: AppColors.textLight,
                                        height: 2.2,
                                        fontSize: 24,
                                      ),
                                      children: _buildSpans(),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),

                        // Processing indicator
                        if (_isProcessing) ...[
                          const SizedBox(height: 24),
                          Container(
                            padding: const EdgeInsets.all(20),
                            decoration: BoxDecoration(
                              color: AppColors.surface,
                              borderRadius:
                                  BorderRadius.circular(Dims.radius),
                              border: Border.all(
                                  color: AppColors.gold.withOpacity(0.2)),
                            ),
                            child: Row(
                              mainAxisAlignment:
                                  MainAxisAlignment.center,
                              children: [
                                const SizedBox(
                                  width: 20,
                                  height: 20,
                                  child: CircularProgressIndicator(
                                      color: AppColors.gold,
                                      strokeWidth: 2),
                                ),
                                const SizedBox(width: 12),
                                Text(
                                  'Analyzing your recitation...',
                                  style: AppText.body(
                                      color: AppColors.gold),
                                ),
                              ],
                            ),
                          ),
                        ],

                        // Tajweed tip
                        if (_currentTajweedTip != null &&
                            !_sessionDone &&
                            !_isProcessing) ...[
                          const SizedBox(height: 24),
                          Container(
                            padding: const EdgeInsets.all(16),
                            decoration: BoxDecoration(
                              color:
                                  AppColors.emerald.withOpacity(0.06),
                              borderRadius:
                                  BorderRadius.circular(Dims.radius),
                              border: Border.all(
                                  color: AppColors.emerald
                                      .withOpacity(0.12)),
                            ),
                            child: Row(
                              children: [
                                const Icon(
                                    Icons.lightbulb_outline_rounded,
                                    color: AppColors.gold,
                                    size: 20),
                                const SizedBox(width: 10),
                                Expanded(
                                  child: Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      Text(
                                        'Tajweed Hint',
                                        style: AppText.caption(
                                                color: AppColors.gold)
                                            .copyWith(
                                                fontWeight:
                                                    FontWeight.w700),
                                      ),
                                      const SizedBox(height: 4),
                                      Text(_currentTajweedTip!,
                                          style: AppText.body(
                                              color: AppColors
                                                  .textLight)),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],

                        // Session done card
                        if (_sessionDone) ...[
                          const SizedBox(height: 24),
                          Container(
                            padding: const EdgeInsets.all(20),
                            decoration: BoxDecoration(
                              color: AppColors.surface,
                              borderRadius:
                                  BorderRadius.circular(Dims.radius),
                              border: Border.all(
                                  color: AppColors.textLight
                                      .withOpacity(0.05)),
                            ),
                            child: Column(
                              children: [
                                const Icon(
                                    Icons.check_circle_rounded,
                                    color: AppColors.correct,
                                    size: 48),
                                const SizedBox(height: 10),
                                Text('Recitation Complete!',
                                    style: AppText.heading2(
                                        color:
                                            AppColors.textLight)),
                                const SizedBox(height: 16),
                                ElevatedButton.icon(
                                  onPressed: _reset,
                                  icon: const Icon(
                                      Icons.replay_rounded),
                                  label: const Text('Try Again'),
                                  style: ElevatedButton.styleFrom(
                                    backgroundColor:
                                        AppColors.gold,
                                    foregroundColor:
                                        AppColors.primary,
                                    padding:
                                        const EdgeInsets.symmetric(
                                            horizontal: 28,
                                            vertical: 14),
                                    shape:
                                        RoundedRectangleBorder(
                                            borderRadius:
                                                BorderRadius
                                                    .circular(
                                                        14)),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],

                        const SizedBox(height: 100),
                      ],
                    ),
            ),
          ],
        ),
      ),

      // ── Bottom bar ─────────────────────────────────────────────────
      bottomNavigationBar: Container(
        padding: EdgeInsets.only(
          left: 24,
          right: 24,
          top: 20,
          bottom: MediaQuery.of(context).padding.bottom + 16,
        ),
        decoration: BoxDecoration(
          color: AppColors.surface,
          border: Border(
              top: BorderSide(
                  color: AppColors.textLight.withOpacity(0.1))),
          boxShadow: [
            BoxShadow(
              color: AppColors.background.withOpacity(0.5),
              blurRadius: 10,
              offset: const Offset(0, -4),
            )
          ],
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            if (!_sessionDone)
              Text(
                _isProcessing
                    ? 'Processing...'
                    : _isRecording
                        ? 'Recording verse — tap stop when done'
                        : 'Tap mic & recite the highlighted verse',
                style: AppText.caption(
                    color: _isRecording
                        ? AppColors.incorrect
                        : _isProcessing
                            ? AppColors.gold
                            : AppColors.textMuted),
              ),
            const SizedBox(height: 14),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                _RoundBtn(
                  icon: Icons.play_arrow_rounded,
                  color: AppColors.emerald,
                  onTap: _playReferenceAudio,
                ),
                const SizedBox(width: 20),
                AnimatedBuilder(
                  animation: _pulseCtrl,
                  builder: (_, __) => GestureDetector(
                    onTap: (_sessionDone || _isProcessing)
                        ? null
                        : _toggleRecording,
                    child: Container(
                      width: 72,
                      height: 72,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: _isProcessing
                            ? AppColors.textMuted
                            : _isRecording
                                ? AppColors.incorrect
                                : AppColors.gold,
                        boxShadow: [
                          if (!_isProcessing)
                            BoxShadow(
                              color: (_isRecording
                                      ? AppColors.incorrect
                                      : AppColors.gold)
                                  .withOpacity(
                                      0.35 +
                                          _pulseCtrl.value * 0.15),
                              blurRadius:
                                  20 + _pulseCtrl.value * 8,
                              spreadRadius: 2,
                            ),
                        ],
                      ),
                      child: _isProcessing
                          ? Padding(
                              padding: const EdgeInsets.all(20),
                              child: CircularProgressIndicator(
                                color: AppColors.textLight,
                                strokeWidth: 3,
                              ),
                            )
                          : Icon(
                              _isRecording
                                  ? Icons.stop_rounded
                                  : Icons.mic_rounded,
                              color: AppColors.primary,
                              size: 32,
                            ),
                    ),
                  ),
                ),
                const SizedBox(width: 20),
                _RoundBtn(
                  icon: Icons.skip_next_rounded,
                  color: AppColors.textMuted,
                  onTap: _skipVerse,
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class _RoundBtn extends StatelessWidget {
  final IconData icon;
  final Color color;
  final VoidCallback onTap;
  const _RoundBtn(
      {required this.icon, required this.color, required this.onTap});

  @override
  Widget build(BuildContext context) => GestureDetector(
        onTap: onTap,
        child: Container(
          width: 48,
          height: 48,
          decoration: BoxDecoration(
            color: color.withOpacity(0.1),
            shape: BoxShape.circle,
            border: Border.all(color: color.withOpacity(0.15)),
          ),
          child: Icon(icon, color: color, size: 22),
        ),
      );
}
