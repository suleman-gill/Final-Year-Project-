import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:just_audio/just_audio.dart';
import '../../config/theme.dart';

// ── Result model ──────────────────────────────────────────────────────
class WordResult {
  final String arabic;
  final bool isCorrect;
  final String? errorType;
  final String? tajweedTip;
  final double confidence;

  const WordResult({
    required this.arabic,
    required this.isCorrect,
    this.errorType,
    this.tajweedTip,
    required this.confidence,
  });
}

// ── Screen ────────────────────────────────────────────────────────────
class RecitationResultsScreen extends StatefulWidget {
  final int surahNum;
  final int ayahNum;
  final List<WordResult> wordResults;
  final int correctCount;
  final int wrongCount;
  final int totalWords;

  const RecitationResultsScreen({
    super.key,
    required this.surahNum,
    required this.ayahNum,
    required this.wordResults,
    required this.correctCount,
    required this.wrongCount,
    required this.totalWords,
  });

  @override
  State<RecitationResultsScreen> createState() => _RecitationResultsScreenState();
}

class _RecitationResultsScreenState extends State<RecitationResultsScreen> {
  late final AudioPlayer _player;
  bool _isPlaying = false;

  double get accuracy =>
      widget.totalWords > 0 ? (widget.correctCount / widget.totalWords) * 100 : 0;

  List<WordResult> get errors =>
      widget.wordResults.where((w) => !w.isCorrect).toList();

  @override
  void initState() {
    super.initState();
    _player = AudioPlayer();
    _player.playerStateStream.listen((s) {
      if (mounted) {
        setState(() => _isPlaying = s.playing);
      }
    });
  }

  @override
  void dispose() {
    _player.dispose();
    super.dispose();
  }

  Future<void> _playQariAudio() async {
    try {
      final s = widget.surahNum.toString().padLeft(3, '0');
      final a = widget.ayahNum.toString().padLeft(3, '0');
      final url = 'https://everyayah.com/data/Abdul_Basit_Murattal_64kbps/$s$a.mp3';
      if (_isPlaying) {
        await _player.stop();
      } else {
        await _player.setUrl(url);
        await _player.play();
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Could not play audio: $e')),
        );
      }
    }
  }

  Color get _accuracyColor {
    if (accuracy >= 80) return AppColors.correct;
    if (accuracy >= 60) return AppColors.gold;
    return AppColors.incorrect;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        backgroundColor: AppColors.primary,
        elevation: 0,
        leading: IconButton(
          icon: Icon(Icons.close_rounded, color: AppColors.textLight),
          onPressed: () => context.pop(),
        ),
        title: Text(
          'Recitation Results',
          style: AppText.heading2(color: AppColors.textLight),
        ),
      ),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [

          // ── Accuracy Card ──────────────────────────────────────────
          Container(
            padding: const EdgeInsets.symmetric(vertical: 28, horizontal: 20),
            decoration: BoxDecoration(
              color: AppColors.surface,
              borderRadius: BorderRadius.circular(Dims.radius),
              border: Border.all(color: _accuracyColor.withOpacity(0.2)),
            ),
            child: Column(
              children: [
                Text(
                  'Overall Accuracy',
                  style: AppText.caption(color: AppColors.textMuted),
                ),
                const SizedBox(height: 10),
                Text(
                  '${accuracy.toStringAsFixed(1)}%',
                  style: TextStyle(
                    fontSize: 52,
                    fontWeight: FontWeight.bold,
                    color: _accuracyColor,
                  ),
                ),
                const SizedBox(height: 20),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    _StatBadge(
                      label: 'Correct',
                      value: '${widget.correctCount}',
                      color: AppColors.correct,
                    ),
                    _StatBadge(
                      label: 'Wrong',
                      value: '${widget.wrongCount}',
                      color: AppColors.incorrect,
                    ),
                    _StatBadge(
                      label: 'Total',
                      value: '${widget.totalWords}',
                      color: AppColors.gold,
                    ),
                  ],
                ),
              ],
            ),
          ),

          const SizedBox(height: 20),

          // ── Word Review ────────────────────────────────────────────
          Text(
            'Word by Word',
            style: AppText.heading2(color: AppColors.textLight),
          ),
          const SizedBox(height: 12),
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: AppColors.surface,
              borderRadius: BorderRadius.circular(Dims.radius),
            ),
            child: Wrap(
              spacing: 8,
              runSpacing: 10,
              children: widget.wordResults
                  .map((w) => _WordChip(result: w))
                  .toList(),
            ),
          ),

          const SizedBox(height: 20),

          // ── Tajweed Errors ─────────────────────────────────────────
          if (errors.isNotEmpty) ...[
            Text(
              'Tajweed Errors (${errors.length})',
              style: AppText.heading2(color: AppColors.textLight),
            ),
            const SizedBox(height: 12),
            ...errors.map((e) => _ErrorCard(result: e)),
            const SizedBox(height: 20),
          ],

          if (errors.isEmpty) ...[
            Container(
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                color: AppColors.correct.withOpacity(0.08),
                borderRadius: BorderRadius.circular(Dims.radius),
                border: Border.all(color: AppColors.correct.withOpacity(0.2)),
              ),
              child: Row(
                children: [
                  const Icon(Icons.check_circle_rounded, color: AppColors.correct, size: 28),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Text(
                      'Excellent! No Tajweed errors detected. Perfect recitation!',
                      style: AppText.body(color: AppColors.correct),
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 20),
          ],

          // ── Qari Reference Audio ───────────────────────────────────
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: AppColors.surface,
              borderRadius: BorderRadius.circular(Dims.radius),
              border: Border.all(color: AppColors.gold.withOpacity(0.15)),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Icon(Icons.record_voice_over_rounded,
                        color: AppColors.gold, size: 20),
                    const SizedBox(width: 8),
                    Text(
                      'Reference Recitation',
                      style: AppText.caption(color: AppColors.gold)
                          .copyWith(fontWeight: FontWeight.w700),
                    ),
                  ],
                ),
                const SizedBox(height: 4),
                Text(
                  'Sheikh Abdul Basit Murattal',
                  style: AppText.body(color: AppColors.textMuted),
                ),
                const SizedBox(height: 12),
                SizedBox(
                  width: double.infinity,
                  child: ElevatedButton.icon(
                    onPressed: _playQariAudio,
                    icon: Icon(
                      _isPlaying ? Icons.stop_rounded : Icons.play_arrow_rounded,
                    ),
                    label: Text(_isPlaying ? 'Stop' : 'Play Correct Recitation'),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: AppColors.gold.withOpacity(0.15),
                      foregroundColor: AppColors.gold,
                      elevation: 0,
                      padding: const EdgeInsets.symmetric(vertical: 14),
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12)),
                    ),
                  ),
                ),
              ],
            ),
          ),

          const SizedBox(height: 28),

          // ── Action Buttons ─────────────────────────────────────────
          Row(
            children: [
              Expanded(
                child: OutlinedButton.icon(
                  onPressed: () => context.pop(),
                  icon: const Icon(Icons.replay_rounded),
                  label: const Text('Try Again'),
                  style: OutlinedButton.styleFrom(
                    foregroundColor: AppColors.gold,
                    side: BorderSide(color: AppColors.gold.withOpacity(0.4)),
                    padding: const EdgeInsets.symmetric(vertical: 14),
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(14)),
                  ),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: ElevatedButton.icon(
                  onPressed: () => context.go('/recite-select'),
                  icon: const Icon(Icons.navigate_next_rounded),
                  label: const Text('New Surah'),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: AppColors.gold,
                    foregroundColor: AppColors.primary,
                    padding: const EdgeInsets.symmetric(vertical: 14),
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(14)),
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 32),
        ],
      ),
    );
  }
}

// ── Sub-widgets ───────────────────────────────────────────────────────

class _StatBadge extends StatelessWidget {
  final String label;
  final String value;
  final Color color;
  const _StatBadge(
      {required this.label, required this.value, required this.color});

  @override
  Widget build(BuildContext context) => Column(
        children: [
          Text(value,
              style: TextStyle(
                  fontSize: 30, fontWeight: FontWeight.bold, color: color)),
          const SizedBox(height: 4),
          Text(label, style: AppText.caption(color: AppColors.textMuted)),
        ],
      );
}

class _WordChip extends StatelessWidget {
  final WordResult result;
  const _WordChip({required this.result});

  @override
  Widget build(BuildContext context) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
        decoration: BoxDecoration(
          color: result.isCorrect
              ? AppColors.correct.withOpacity(0.1)
              : AppColors.incorrect.withOpacity(0.1),
          borderRadius: BorderRadius.circular(8),
          border: Border.all(
            color: result.isCorrect
                ? AppColors.correct.withOpacity(0.25)
                : AppColors.incorrect.withOpacity(0.25),
          ),
        ),
        child: Text(
          result.arabic,
          style: AppText.arabicMedium.copyWith(
            color: result.isCorrect ? AppColors.correct : AppColors.incorrect,
            fontSize: 18,
          ),
          textDirection: TextDirection.rtl,
        ),
      );
}

class _ErrorCard extends StatelessWidget {
  final WordResult result;
  const _ErrorCard({required this.result});

  @override
  Widget build(BuildContext context) => Container(
        margin: const EdgeInsets.only(bottom: 10),
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: AppColors.surface,
          borderRadius: BorderRadius.circular(Dims.radius),
          border: Border.all(color: AppColors.incorrect.withOpacity(0.18)),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Container(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                  decoration: BoxDecoration(
                    color: AppColors.incorrect.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(6),
                  ),
                  child: Text(
                    result.arabic,
                    style: AppText.arabicMedium.copyWith(
                        color: AppColors.incorrect, fontSize: 20),
                    textDirection: TextDirection.rtl,
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      if (result.errorType != null)
                        Container(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 8, vertical: 3),
                          decoration: BoxDecoration(
                            color: AppColors.gold.withOpacity(0.12),
                            borderRadius: BorderRadius.circular(4),
                          ),
                          child: Text(
                            result.errorType!,
                            style: AppText.caption(color: AppColors.gold)
                                .copyWith(fontWeight: FontWeight.w700),
                          ),
                        ),
                      const SizedBox(height: 4),
                      Text(
                        'Confidence: ${(result.confidence * 100).toStringAsFixed(0)}%',
                        style: AppText.caption(color: AppColors.textMuted),
                      ),
                    ],
                  ),
                ),
              ],
            ),
            if (result.tajweedTip != null && result.tajweedTip!.isNotEmpty) ...[
              const SizedBox(height: 10),
              Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Icon(Icons.lightbulb_outline_rounded,
                      color: AppColors.gold, size: 16),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Text(
                      result.tajweedTip!,
                      style: AppText.body(
                          color: AppColors.textLight.withOpacity(0.85)),
                    ),
                  ),
                ],
              ),
            ],
          ],
        ),
      );
}
