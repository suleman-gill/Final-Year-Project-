import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import '../features/auth/auth_notifier.dart';

import '../screens/splash/splash_screen.dart';
import '../screens/auth/onboarding_screen.dart';
import '../screens/auth/login_screen.dart';
import '../screens/auth/register_screen.dart';
import '../screens/auth/forgot_password_screen.dart';


import '../screens/home/home_screen.dart';
import '../screens/quran/surah_list_screen.dart';
import '../screens/quran/quran_reader_screen.dart';
import '../screens/recitation/surah_selection_screen.dart';
import '../screens/recitation/recitation_screen.dart';
import '../screens/recitation/recitation_results_screen.dart';
import '../screens/prayer/prayer_screen.dart';
import '../screens/qibla/qibla_screen.dart';
import '../screens/profile/profile_screen.dart';

import '../widgets/common/main_shell.dart';

final rootNavigatorKey = GlobalKey<NavigatorState>();

class RouterNotifier extends ChangeNotifier {
  final Ref _ref;

  RouterNotifier(this._ref) {
    _ref.listen<AuthState>(
      authProvider,
      (_, __) => notifyListeners(),
    );
  }

  String? redirect(BuildContext context, GoRouterState state) {
    final authState = _ref.read(authProvider);
    final isAuth = authState.isAuthenticated;
    
    final isSplash = state.uri.toString() == '/splash';
    final isLogin = state.uri.toString() == '/login';
    final isRegister = state.uri.toString() == '/register';
    final isForgotPassword = state.uri.toString() == '/forgot-password';
    final isOnboarding = state.uri.toString() == '/onboarding';

    final isAuthRoute = isLogin || isRegister || isForgotPassword || isOnboarding;

    if (isSplash) {
      return null; 
    }

    if (!isAuth && !isAuthRoute) {
      return '/login';
    }

    if (isAuth && isAuthRoute) {
      return '/home';
    }

    return null;
  }
}

final routerProvider = Provider<GoRouter>((ref) {
  final notifier = RouterNotifier(ref);

  return GoRouter(
    navigatorKey: rootNavigatorKey,
    initialLocation: '/splash',
    refreshListenable: notifier,
    redirect: notifier.redirect,
    routes: [
      // Non-shell routes
    GoRoute(
      path: '/splash',
      builder: (_, __) => const SplashScreen(),
    ),
    GoRoute(
      path: '/onboarding',
      builder: (_, __) => const OnboardingScreen(),
    ),
    GoRoute(
      path: '/login',
      builder: (_, __) => const LoginScreen(),
    ),
    GoRoute(
      path: '/register',
      builder: (_, __) => const RegisterScreen(),
    ),
    GoRoute(
      path: '/forgot-password',
      builder: (_, __) => const ForgotPasswordScreen(),
    ),



    // Main App Tab Shell
    ShellRoute(
      builder: (context, state, child) => MainShell(child: child),
      routes: [
        GoRoute(
          path: '/home',      
          builder: (_, __) => const HomeScreen(),
        ),
        GoRoute(
          path: '/quran',     
          builder: (_, __) => const SurahListScreen(),
        ),
        GoRoute(
          path: '/quran/:surahNum',
          builder: (context, state) {
            final num = int.tryParse(state.pathParameters['surahNum'] ?? '1') ?? 1;
            return QuranReaderScreen(surahNumber: num);
          },
        ),
        // Recite tab → Surah Selection (forces user to pick before recording)
        GoRoute(
          path: '/recite-select',
          builder: (_, __) => const SurahSelectionScreen(),
        ),
        // Actual recitation screen (navigated to from selection or reader)
        GoRoute(
          path: '/recitation', 
          builder: (context, state) {
            final surahNum = int.tryParse(state.uri.queryParameters['surahNum'] ?? '');
            final ayahNum = int.tryParse(state.uri.queryParameters['ayahNum'] ?? '');
            return RecitationScreen(surahNum: surahNum, ayahNum: ayahNum);
          },
        ),
        GoRoute(
          path: '/recitation/results',
          builder: (context, state) {
            final extra = state.extra as Map<String, dynamic>;
            return RecitationResultsScreen(
              surahNum: extra['surahNum'] as int,
              ayahNum: extra['ayahNum'] as int,
              wordResults: extra['wordResults'] as List<WordResult>,
              correctCount: extra['correctCount'] as int,
              wrongCount: extra['wrongCount'] as int,
              totalWords: extra['totalWords'] as int,
            );
          },
        ),
        GoRoute(
          path: '/prayer',     
          builder: (_, __) => const PrayerScreen(),
        ),
        GoRoute(
          path: '/qibla',      
          builder: (_, __) => const QiblaScreen(),
        ),
        GoRoute(
          path: '/profile',    
          builder: (_, __) => const ProfileScreen(),
        ),

      ],
    ),
  ],
);
});
