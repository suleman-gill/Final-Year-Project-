import 'package:hive_flutter/hive_flutter.dart';

class HiveStorage {
  static late Box _settingsBox;
  static late Box _bookmarksBox;
  static late Box _historyBox;

  static Future<void> initialize() async {
    await Hive.initFlutter();
    
    // Open boxes
    _settingsBox = await Hive.openBox('settings');
    _bookmarksBox = await Hive.openBox('bookmarks');
    _historyBox = await Hive.openBox('history');
  }

  static void initializeTest({
    required Box settingsBox,
    required Box bookmarksBox,
    required Box historyBox,
  }) {
    _settingsBox = settingsBox;
    _bookmarksBox = bookmarksBox;
    _historyBox = historyBox;
  }

  // Settings
  static double getFontSizeMultiplier() {
    return _settingsBox.get('font_size_multiplier', defaultValue: 1.0) as double;
  }

  static Future<void> setFontSizeMultiplier(double val) async {
    await _settingsBox.put('font_size_multiplier', val);
  }

  static bool isLightMode() {
    return _settingsBox.get('light_mode', defaultValue: false) as bool;
  }

  static Future<void> setLightMode(bool val) async {
    await _settingsBox.put('light_mode', val);
  }

  // Bookmarks
  static List<int> getBookmarks() {
    final list = _bookmarksBox.get('surahs', defaultValue: <int>[]) as List;
    return list.cast<int>();
  }

  static Future<void> toggleBookmark(int surahNum) async {
    final list = getBookmarks();
    if (list.contains(surahNum)) {
      list.remove(surahNum);
    } else {
      list.add(surahNum);
    }
    await _bookmarksBox.put('surahs', list);
  }

  static bool isBookmarked(int surahNum) {
    return getBookmarks().contains(surahNum);
  }

  // Generic helpers for settings box
  static T? get<T>(String key) {
    return _settingsBox.get(key) as T?;
  }

  static Future<void> put(String key, dynamic value) async {
    await _settingsBox.put(key, value);
  }
}
