# 🌙 Tilawah AI

> A premium, production-ready Islamic learning platform and Quran recitation companion.

Tilawah AI is a modern cross-platform application built to help Muslims of all ages refine their Quranic recitation and Tajweed. It combines real-time AI voice feedback, continuous recitation streaks, interactive Islamic utilities, and a clean, luxury interface.

![Flutter](https://img.shields.io/badge/Flutter-02569B?style=for-the-badge&logo=flutter&logoColor=white)
![FastAPI](https://img.shields.io/badge/FastAPI-005571?style=for-the-badge&logo=fastapi)
![Python](https://img.shields.io/badge/Python-3776AB?style=for-the-badge&logo=python&logoColor=white)
![Dart](https://img.shields.io/badge/Dart-0175C2?style=for-the-badge&logo=dart&logoColor=white)

---

## ✨ Features

- 🎙️ **Interactive AI Recitation:** Stream your voice in real-time to receive word-by-word pronunciation highlights and Tajweed corrections.
- 📖 **Quran Reader:** A beautiful, justified Arabic text reader using the *Scheherazade New* font family, featuring toggleable English translations.
- 🕌 **Islamic Utilities:** High-precision Qibla compass using device geolocation and automated prayer times.
- 🤖 **AI Islamic Tutor:** A built-in chat assistant that provides Tafsir (interpretations) and scholarly answers.
- 🏆 **Gamification & Streaks:** Earn XP, level up, and maintain reading streaks to stay motivated.
- 🌗 **Luxury Themes:** Premium Night Mode (Deep Blue Slate) and Classic Islamic light mode (Cream & Emerald).

---

## 🏗 Architecture & Dual ML Engines

Tilawah AI features a modular Client-Server architecture designed to work out-of-the-box:

```mermaid
graph TD
    Client[Flutter Mobile App] <-->|WebSocket Real-time Audio| WS[FastAPI WebSocket Endpoint]
    WS --> EngineFactory{Engine Factory}
    EngineFactory -->|MODEL_PATH is set| ProdEngine[Wav2Vec2 Fine-Tuned Tajweed Model]
    EngineFactory -->|MODEL_PATH is empty| FallbackEngine[Fallback Calculated Engine]
    FallbackEngine -->|Deterministic Analysis| Result[Tajweed / Correctness Feedback]
    ProdEngine -->|CTC Token Matching| Result
    Result -->|JSON Payload| Client
```

### 🧠 Inference Engines
1. **Production Engine (`TilawahModelEngine`):** Loads a fine-tuned Wav2Vec2 model when the `MODEL_PATH` environment variable points to a model directory. It compares predicted phonemes and Tajweed rules (e.g. *Qalqalah*, *Ghunnah*) using token alignment.
2. **Fallback Engine (`FallbackCalculatedEngine`):** Designed for local development and testing. It analyzes audio duration, energy levels, and phoneme complexity to deterministically evaluate recitation correctness without needing massive model weights or GPU resources.

---

## 🚀 Quick Start Guide

### Prerequisites
- [Flutter SDK](https://docs.flutter.dev/get-started/install) (latest stable)
- [Python 3.10+](https://www.python.org/downloads/)
- [PostgreSQL](https://www.postgresql.org/) (optional; defaults to SQLite automatically for local development)
- [Redis](https://redis.io/) (optional; fallback database session caching)

---

### 1. Setup the Backend

1. Navigate to the `backend` directory:
   ```bash
   cd backend
   ```
2. Create and activate a virtual environment:
   ```bash
   python -m venv .venv
   source .venv/bin/activate  # On Windows use: .venv\Scripts\activate
   ```
3. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```
4. Setup environment variables:
   - Copy the environment template:
     ```bash
     cp .env.example .env
     ```
   - (Optional) Configure database credentials and API keys in `.env`. Leaving `DATABASE_URL` empty or as default will auto-initialize a local `tilawah.db` SQLite file.
   - Leave `MODEL_PATH` empty to automatically run the deterministic **Fallback Engine**.
5. Apply migrations:
   ```bash
   alembic upgrade head
   ```
6. Start the server:
   ```bash
   python run.py
   ```
   *The server will run at `http://localhost:8000`*

---

### 2. Setup the Frontend

1. Navigate to the `frontend` directory:
   ```bash
   cd ../frontend
   ```
2. Fetch the Flutter packages:
   ```bash
   flutter pub get
   ```
3. (Optional) Configure Firebase:
   - To enable Firebase Auth, place your `google-services.json` inside `android/app/` and run `flutterfire configure` to generate `lib/firebase_options.dart`.
4. Run the app:
   ```bash
   flutter run
   ```
   *(Supports iOS simulator, Android emulator, and Chrome for web).*

---

## 🔒 Secrets & Configurations
* For security, the following configurations are ignored by git and should not be committed:
  - `.env` and `backend/.env`
  - `backend/firebase_service_account.json`
  - `frontend/android/app/google-services.json`
  - All large model weight files under `model/` or `backend/models/`

---

## 📖 The ELI5 Explanation
How does the real-time recitation work?
Imagine your phone is a **Walkie-Talkie**, and far away sits a **Wise Teacher** (the Backend Server). As you read the Quran, your voice is instantly sent down a magical thread (the WebSocket) to the Teacher. The Teacher listens, compares your voice to their giant textbook, and instantly shouts back **"Green!"** if you are correct, or **"Red!"** if you made a mistake. When you finish, the Teacher writes your score in their notebook and gives you XP points!

---

*Built with ❤️ for the Ummah.*

